<?php 
/*
 *	Made by Partydragen
 *  http://partydragen.com/
 *
 *  Modified by Samerton
 *  https://worldscapemc.co.uk
 *
 */

// Language file for "members" addon

$members_language = array(
	'members' => 'Jäsenet',
	'members_icon' => '', // Icon to display before the text in the navbar
	'username' => 'Käyttäjänimi',
	'group' => 'Ryhmä',
	'created' => 'Liittynyt',
);
