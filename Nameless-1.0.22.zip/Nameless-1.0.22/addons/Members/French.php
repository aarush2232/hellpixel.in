
<?php 
/*
 *	Made by Partydragen
 *  http://partydragen.com/
 *
 *  Modified by Samerton
 *  https://worldscapemc.co.uk/
 *
 *  Translated by Aviortheking
 *  https://delta-wings.net/
 *
 */
// Language file for "members" addon
$members_language = array(
	'members' => 'Membres',
	'members_icon' => '', // Icon to display before the text in the navbar
	'username' => 'Nom d\'utilisateur',
	'group' => 'Groupe',
	'created' => 'Rejoins le',
);
