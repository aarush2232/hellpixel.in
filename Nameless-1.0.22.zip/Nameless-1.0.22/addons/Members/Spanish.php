<?php 
/*
 *	Hecho por Partydragen
 *  http://partydragen.com/
 *
 *  Modificado por JosGCS
 *  https://twitter.com/iJosGCS
 *
 */
// Archivo de idioma para el complemento de "miembros".
$members_language = array(
	'members' => 'Miembros',
	'members_icon' => '', // Ícono a mostrar en la barra de navegación.
	'username' => 'Usuario',
	'group' => 'Grupo',
	'created' => 'Fecha de Registro',
);
