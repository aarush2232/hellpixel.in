<?php 
/*
 *	Made by Partydragen
 *  http://partydragen.com/
 *
 */
// Language file for "members" addon
$members_language = array(
	'members' => 'Medlemmer',
	'members_icon' => '', // Ikonet for å vise før teksten i navbar
	'username' => 'Brukernavn',
	'group' => 'gruppe',
	'created' => 'Joined',
);
