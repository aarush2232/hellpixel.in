<?php 
/*
 *	Made by Samerton
 *  http://worldscapemc.co.uk
 *
 *  License: MIT
 * Copyright (c) 2016 Samerton
 */

// Language file for "Donate" addon

$donate_language = array(
	'donate' => 'Přispět',
	'donate_icon' => '', // Icon to display before "Donate" in navbar
	'latest_donors' => 'Nejnovější přispěvatelé',
	'agree_with_terms' => 'Přispěním souhlasíte s pravidly a podmínkami',
	'link' => '(Odkaz)',
	'agree' => 'Souhlasím &raquo;',
	'cancel' => 'Zrušit',
	'select' => 'Vybrat'
);
